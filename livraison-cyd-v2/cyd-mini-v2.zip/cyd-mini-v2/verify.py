from pathlib import Path
import numpy as np
import trimesh,json
root=Path(__file__).resolve().parent
meshes={};result={}
for p in sorted((root/'stl').glob('*.stl')):
 m=trimesh.load_mesh(p)
 assert m.is_watertight and m.is_winding_consistent and m.body_count==1 and m.volume>0,p.name
 meshes[p.stem]=m
 result[p.stem]={'closed':True,'solids':m.body_count,'dimensions_mm':m.extents.round(3).tolist()}
a=np.radians(10);F=trimesh.transformations.translation_matrix([0,0,55])@trimesh.transformations.rotation_matrix(-a,[1,0,0])@np.diag([1,1,-1,1])
meshes['face'].apply_transform(F)
meshes['carrier'].apply_transform(F@trimesh.transformations.translation_matrix([0,0,13.1])@np.diag([1,1,-1,1]))
meshes['diffuser'].apply_transform(F@trimesh.transformations.translation_matrix([35.5,4.7,2.8])@np.diag([1,1,-1,1]))
for name,x in [('button_minus',39),('button_mute',55),('button_plus',71)]:
 meshes[name].apply_transform(trimesh.transformations.translation_matrix([x,59.2,30])@trimesh.transformations.rotation_matrix(-np.pi/2,[1,0,0]))
# The board envelope is deliberately only a mechanical reference, without components.
pcb=trimesh.creation.box([86,50,1.6]);pcb.apply_translation([55,32.5,7.3]);pcb.apply_transform(F);meshes['pcb_envelope']=pcb
collisions={}
for one,two in [('body','face'),('body','rear'),('body','carrier'),('body','pcb_envelope'),('carrier','pcb_envelope'),('face','diffuser'),('body','button_minus'),('body','button_mute'),('body','button_plus')]:
 overlap=trimesh.boolean.intersection([meshes[one],meshes[two]],engine='manifold')
 vol=abs(overlap.volume) if overlap is not None else 0
 collisions[f'{one}/{two}']=round(vol,5)
 print(one,two,'overlap mm3:',round(vol,5))
result['intersection_volumes_mm3']=collisions
(root/'validation.json').write_text(json.dumps(result,indent=2))
assert max(collisions.values()) < .05, 'Unintended overlap in assembly'
print('Eight STL files valid; tested assembly intersections below 0.05 mm3.')
