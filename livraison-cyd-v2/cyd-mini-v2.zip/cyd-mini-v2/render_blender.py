import bpy, math, json, sys
from pathlib import Path
from mathutils import Matrix, Vector
from bpy_extras.object_utils import world_to_camera_view
root=Path(__file__).resolve().parent
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
scene=bpy.context.scene
scene.render.engine='CYCLES';scene.cycles.samples=64;scene.cycles.use_denoising=False
scene.render.threads_mode='FIXED';scene.render.threads=6
scene.render.resolution_percentage=100
scene.render.film_transparent=True
scene.world.color=(.8,.8,.8)
scene.view_settings.view_transform='AgX'
world=scene.world;world.use_nodes=True;world.node_tree.nodes['Background'].inputs[0].default_value=(.85,.88,.94,1);world.node_tree.nodes['Background'].inputs[1].default_value=.5

def material(name,color,roughness,cloth=False):
 m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);m.use_nodes=True
 p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*color,1);p.inputs['Roughness'].default_value=roughness
 if cloth:
  p.inputs['Sheen Weight'].default_value=.35
  tex=m.node_tree.nodes.new('ShaderNodeTexNoise');tex.inputs['Scale'].default_value=320;tex.inputs['Detail'].default_value=2
  bump=m.node_tree.nodes.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.35;bump.inputs['Distance'].default_value=.0002
  m.node_tree.links.new(tex.outputs['Fac'],bump.inputs['Height']);m.node_tree.links.new(bump.outputs['Normal'],p.inputs['Normal'])
 return m
mats={
'body':material('Tissu anthracite collé - finition optionnelle',(.07,.075,.082),.86,True),
'face':material('Façade noire brillante',(.012,.015,.02),.18),
'rear':material('Dos PETG noir',(.065,.07,.08),.45),
'carrier':material('Support PETG gris',(.28,.31,.35),.6),
'button':material('Boutons noirs',(.08,.085,.095),.65),
'diffuser':material('Diffuseur translucide',(.5,.82,.9),.35),
'pcb':material('PCB jaune - reference non imprimable',(.67,.44,.025),.4),
'glass':material('Ecran CYD - reference non imprimable',(.012,.032,.05),.16),
'frame':material('Cadre LCD - reference',(.12,.14,.15),.4)}
a=math.radians(10)
R=Matrix.Rotation(-a,4,'X');M=Matrix.Diagonal(Vector((1,1,-1,1)))
F=Matrix.Translation(Vector((0,0,55)))@R@M
S=Matrix.Diagonal(Vector((.001,.001,.001,1)))
objects={};transforms={}
for name in ['body','rear','face','carrier','diffuser','button_minus','button_mute','button_plus']:
 bpy.ops.wm.stl_import(filepath=str(root/'stl'/f'{name}.stl'))
 ob=bpy.context.object;ob.name=name
 tr=Matrix.Identity(4)
 if name=='face':tr=F
 if name=='carrier':tr=F@Matrix.Translation((0,0,13.1))@M
 if name=='diffuser':tr=F@Matrix.Translation((35.5,4.7,2.8))@M
 if name.startswith('button_'):
  x={'button_minus':39,'button_mute':55,'button_plus':71}[name]
  tr=Matrix.Translation((x,59.2,30))@Matrix.Rotation(-math.pi/2,4,'X')
 ob.matrix_world=S@tr
 ob.data.materials.clear();ob.data.materials.append(mats['button' if name.startswith('button_') else name])
 objects[name]=ob;transforms[name]=tr
 # Keep normals flat: the actual exported STL geometry remains visible.

def box(name,origin,size,mat):
 bpy.ops.mesh.primitive_cube_add(size=1)
 ob=bpy.context.object;ob.name=name
 tr=F@Matrix.Translation(Vector(origin)+Vector(size)/2)@Matrix.Diagonal(Vector((*size,1)))
 ob.matrix_world=S@tr;ob.data.materials.append(mats[mat]);objects[name]=ob;transforms[name]=tr
box('PCB CYD',(12,7.5,6.5),(86,50,1.6),'pcb')
box('Cadre LCD',(24.5,9.5,3),(61,46,3.5),'frame')
box('Surface écran',(26,10.5,2.5),(58,44,.5),'glass')
# Reference holes and components are intentionally omitted; this is an envelope.

def area(name,location,power,size):
 bpy.ops.object.light_add(type='AREA',location=location);ob=bpy.context.object;ob.name=name;ob.data.energy=power;ob.data.shape='DISK';ob.data.size=size
 ob.rotation_euler=(Vector((.05,.03,.03))-ob.location).to_track_quat('-Z','Y').to_euler()
area('Softbox principale',(-.2,.4,.45),3.5,.5)
area('Remplissage',(.4,.16,.2),2,.3)
area('Liseré arrière',(.1,.4,-.3),3,.25)
bpy.ops.object.camera_add();camera=bpy.context.object;scene.camera=camera;camera.data.type='ORTHO';camera.data.lens=50

def aim(pos,target,scale):
 camera.location=Vector(pos)
 direction=(Vector(target)-camera.location).normalized()
 right=direction.cross(Vector((0,1,0))).normalized();up=right.cross(direction)
 camera.rotation_euler=Matrix((right,up,-direction)).transposed().to_euler()
 camera.data.ortho_scale=scale

def render(name,width,height):
 scene.render.resolution_x=width;scene.render.resolution_y=height;scene.render.image_settings.file_format='PNG';scene.render.filepath=str(root/name);bpy.ops.render.render(write_still=True)

# Assembled product view.
aim((.22,.16,.28),(.055,.032,.026),.17)
render('assemble-v2.png',1400,1100)
# Exploded positions in mm. Five layers follow the actual assembly order.
shifts={'face':(-180,3,100),'carrier':(-20,3,40),'body':(60,0,0),'rear':(145,0,-35),'diffuser':(-180,-20,100),
'PCB CYD':(-100,3,70),'Cadre LCD':(-100,3,70),'Surface écran':(-100,3,70),
'button_minus':(60,27,0),'button_mute':(60,27,0),'button_plus':(60,27,0)}
for name,ob in objects.items():ob.matrix_world=S@Matrix.Translation(shifts[name])@transforms[name]
aim((.35,.26,.65),(.04,.04,.065),.53)
render('eclate-v2-brut.png',2200,1250)
anchors={}
for name in ['face','carrier','body','rear','diffuser','PCB CYD','button_mute']:
 ob=objects[name];center=sum((ob.matrix_world@Vector(corner) for corner in ob.bound_box),Vector())/8
 q=world_to_camera_view(scene,camera,center);anchors[name]=[round(q.x*2200),round((1-q.y)*1250)]
(root/'anchors.json').write_text(json.dumps(anchors))
bpy.ops.wm.save_as_mainfile(filepath=str(root/'scene-v2.blend'))
