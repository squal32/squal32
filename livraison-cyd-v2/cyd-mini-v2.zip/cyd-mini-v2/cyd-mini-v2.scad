// Miniature display enclosure inspired by the supplied curved speaker references.
// Millimetres. Original design; no logos. PCB mechanical fit remains provisional.
part="assembly";
W=110; H=64; D=55; tilt=10; FH=H/cos(tilt);
wall=2.4; radius=10; face_t=2;
pcb_w=86; pcb_h=50; holes_x=78; holes_y=42;
pcb_cx=W/2; pcb_cy=32.5;
screen_w=58; screen_h=44;
$fn=64;
module rr(w,h,r){hull()for(x=[r,w-r])for(y=[r,h-r])translate([x,y])circle(r=r);}
module front_frame(){translate([0,0,D])rotate([-tilt,0,0])mirror([0,0,1])children();}
module rear_positions(){for(x=[10,100])for(y=[9,55])translate([x,y,0])children();}
module pcb_positions(){for(x=[pcb_cx-holes_x/2,pcb_cx+holes_x/2])for(y=[pcb_cy-holes_y/2,pcb_cy+holes_y/2])translate([x,y,0])children();}
module carrier_positions(){for(x=[8,102])for(y=[16,49])translate([x,y,0])children();}
module outer(){hull(){
 translate([6,3,2])linear_extrude(.5)rr(98,58,9);
 translate([3,1,6])linear_extrude(.5)rr(104,62,10);
 translate([1,.2,13])linear_extrude(.5)rr(108,63.6,11);
 translate([0,0,22])linear_extrude(.5)rr(110,64,11);
 front_frame()translate([0,0,face_t])linear_extrude(.5)rr(W,FH,radius);
}}
module cavity(){hull(){
 translate([8.4,5.4,-1])linear_extrude(.5)rr(93.2,53.2,6.6);
 translate([5.4,3.4,6])linear_extrude(.5)rr(99.2,57.2,7.6);
 translate([3.4,2.6,13])linear_extrude(.5)rr(103.2,58.8,8.6);
 translate([2.4,2.4,22])linear_extrude(.5)rr(105.2,59.2,8.6);
 front_frame()translate([2.4,2.4,1])linear_extrude(.5)rr(W-4.8,FH-4.8,7.6);
}}
module body(){difference(){union(){
 difference(){outer();cavity();}
 // Rear fastener columns connect to the shell outside the adhesive rectangle.
 rear_positions()translate([0,0,2])cylinder(d=8,h=8);
 // Four internal pads hold the removable board carrier, normal to the front.
 front_frame()for(x=[1,98])for(y=[12,45])translate([x,y,13.1])cube([11,8,5]);
 }
 rear_positions()translate([0,0,1.8])cylinder(d=1.8,h=8.5);
 front_frame()carrier_positions()translate([0,0,12.9])cylinder(d=1.8,h=5.4);
 // Wide provisional service access: original PCB has USB on the short edge.
 translate([102,16,30])cube([10,34,14]);
 // SD on the upper long edge, separate from the button row.
 translate([55,57,34])cube([20,12,8]);
 // Upper/rear cable outlet. A top-mounted USB socket needs a separate extension.
 translate([82,57,7])cube([16,12,12]);
 for(x=[39,55,71])translate([x,68,30])rotate([90,0,0])cylinder(d=5.8,h=11);
 for(x=[29:10:79])translate([x,-2,17])cube([5,6,2]);
}}
module rear(){difference(){
 translate([6,3,0])linear_extrude(2)rr(98,58,9);
 rear_positions(){translate([0,0,-1])cylinder(d=2.4,h=4);translate([0,0,-.01])cylinder(d1=4.4,d2=2.4,h=1.1);}
}}
module face(){difference(){
 linear_extrude(face_t)rr(W,FH,radius);
 translate([(W-screen_w)/2,pcb_cy-screen_h/2,-1])cube([screen_w,screen_h,4]);
 translate([37,5.8,-1])cube([36,1.8,4]);
}}
module carrier(){difference(){union(){
 difference(){translate([6,5,0])linear_extrude(2)rr(98,55,5);
 translate([14,11.5,-1])cube([82,42,4]);}
 pcb_positions()translate([0,0,1])cylinder(d=6,h=4);
 }
 pcb_positions()translate([0,0,.8])cylinder(d=1.8,h=5);
 carrier_positions()translate([0,0,-1])cylinder(d=2.4,h=4);
}}
module button(mark="minus"){union(){cylinder(d=8,h=1.2);translate([0,0,1.2])cylinder(d=5.2,h=4.3);
 if(mark=="minus"||mark=="plus")translate([-1.5,-.3,5.4])cube([3,.6,.5]);
 if(mark=="plus")translate([-.3,-1.5,5.4])cube([.6,3,.5]);
 if(mark=="mute")translate([0,0,5.4])linear_extrude(.5)difference(){circle(d=3);circle(d=1.8);}
}}
module diffuser(){union(){cube([39,4,.8]);translate([1.8,1.4,.8])cube([35.4,1.2,1.2]);}}
// Reference board only, excluded from all printable exports.
module board_reference(){
 color([.86,.65,.04])front_frame()translate([12,7.5,6.5])cube([86,50,1.6]);
 color([.025,.045,.065])front_frame()translate([26,10.5,2.5])cube([58,44,4]);
}
if(part=="body")body();
if(part=="rear")rear();
if(part=="face")face();
if(part=="carrier")carrier();
if(part=="button_minus")button("minus");
if(part=="button_mute")button("mute");
if(part=="button_plus")button("plus");
if(part=="diffuser")diffuser();
if(part=="assembly"){
 color([.12,.13,.15])body();color([.09,.10,.11])rear();
 color([.015,.02,.025])front_frame()face();
 color([.28,.3,.32])front_frame()translate([0,0,13.1])mirror([0,0,1])carrier();
 for(i=[0:2])color([.12,.13,.15])translate([39+i*16,59.2,30])rotate([-90,0,0])button(["minus","mute","plus"][i]);
 color([.6,.9,1])front_frame()translate([35.5,4.7,2.8])mirror([0,0,1])diffuser();
 board_reference();
}
