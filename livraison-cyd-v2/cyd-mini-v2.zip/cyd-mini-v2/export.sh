#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p stl
for part in body rear face carrier button_minus button_mute button_plus diffuser; do
  openscad -o "stl/$part.stl" -D "part=\"$part\"" cyd-mini-v2.scad
done
