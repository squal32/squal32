from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import json
root=Path(__file__).resolve().parent
fontroot=Path('/usr/share/fonts/truetype/dejavu')
def font(n,bold=False): return ImageFont.truetype(str(fontroot/('DejaVuSans-Bold.ttf' if bold else 'DejaVuSans.ttf')),n)
# Construct the engineering plate from the CAD render and its camera-projected anchors.
raw=Image.open(root/'eclate-v2-brut.png').convert('RGBA').crop((0,250,2200,1000))
out=Image.new('RGB',(2200,1170),'white');out.paste(raw,(0,140),raw)
d=ImageDraw.Draw(out)
d.text((55,28),'V2 · VUE ÉCLATÉE',font=font(43,True),fill='#17283a')
d.text((55,86),'Forme arrondie et profonde · écran CYD 2,8″ conservé',font=font(28),fill='#586574')
anchors=json.loads((root/'anchors.json').read_text())
def label(name,title,subtitle,tx,ty,target=None,color='#204b69'):
 ax,ay=anchors[name];ay-=110
 if target is not None: ax,ay=target
 bbox=d.textbbox((0,0),title,font=font(27,True));w=bbox[2]-bbox[0]
 d.text((tx-w/2,ty),title,font=font(27,True),fill=color)
 bbox=d.textbbox((0,0),subtitle,font=font(23));w=bbox[2]-bbox[0]
 d.text((tx-w/2,ty+40),subtitle,font=font(23),fill='#586574')
 end_y=ty-14 if ty>ay else ty+83
 d.line([(ax,ay),(tx,end_y)],fill='#8092a3',width=2)
 d.ellipse((ax-4,ay-4,ax+4,ay+4),fill=color)
label('face','1 · Façade','Noir brillant · 1 pièce',333,162,target=(330,401))
label('PCB CYD','Écran + carte CYD','Électronique · non imprimée',697,873,target=(697,670),color='#9b6b1f')
label('carrier','2 · Support de carte','PETG · 1 pièce',1055,873,target=(1055,690))
label('body','3 · Coque galbée','PETG + tissu collé · 1 pièce',1448,873,target=(1448,726))
label('rear','4 · Dos plat','Zone de collage · 1 pièce',1879,873,target=(1879,662))
label('button_mute','5 · Boutons − / ○ / +','3 pièces à imprimer',1443,162)
label('diffuser','6 · Diffuseur LED','Translucide · 1 pièce',326,873)
d.line((55,1024,2145,1024),fill='#dce3ea',width=2)
d.text((55,1050),'8 pièces à imprimer · boîtier nominal 110 × 64 × 55 mm · façade inclinée de 10°',font=font(27,True),fill='#17283a')
d.text((55,1100),'Rendu des STL. Vis, tissu, interrupteurs et LED à ajouter. Ajustement à la carte réelle à confirmer.',font=font(23),fill='#586574')
out.save(root/'vue-eclatee-v2.png')
raw=Image.open(root/'assemble-v2.png').convert('RGBA');out=Image.new('RGB',(1400,1190),'white');out.paste(raw,(0,70),raw)
d=ImageDraw.Draw(out);d.text((50,22),'V2 · SILHOUETTE ASSEMBLÉE',font=font(33,True),fill='#17283a')
d.text((50,1140),'Façade arrondie · profondeur 55 mm · fenêtre CYD au format 4:3',font=font(24),fill='#586574')
out.save(root/'vue-assemblee-v2.png')
